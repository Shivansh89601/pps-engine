// api/reply.js - Vercel serverless function (ESM)
export default async function handler(req, res) {
  try {
    if (req.method !== "POST") return res.status(405).json({ error: "Only POST" });
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: "No text provided" });
    const key = process.env.OPENROUTER_API_KEY;
    if (!key) return res.status(500).json({ error: "Missing OPENROUTER_API_KEY env var" });

    const resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "deepseek/deepseek-r1:free",
        messages: [
          { role: "system", content: "You are a concise, empathetic friend. Reply in 1-2 short sentences, non-judgmental." },
          { role: "user", content: text }
        ],
        max_tokens: 120
      })
    });

    const j = await resp.json();
    const aiReply = j?.choices?.[0]?.message?.content || (j?.output || "Thanks for sharing.");
    res.setHeader("Access-Control-Allow-Origin", "*");
    return res.status(200).json({ reply: aiReply });
  } catch (err) {
    console.error(err);
    res.setHeader("Access-Control-Allow-Origin", "*");
    return res.status(500).json({ error: "Server error" });
  }
}
