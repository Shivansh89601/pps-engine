// api/save.js - Vercel serverless function: saves post and calls /api/reply
import fs from "fs";
import path from "path";

export default async function handler(req, res) {
  try {
    if (req.method !== "POST") return res.status(405).json({ error: "Only POST" });
    const { text, mood, category } = req.body;
    if (!text) return res.status(400).json({ error: "No text" });

    const vercelUrl = process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : null;
    const replyEndpoint = vercelUrl ? `${vercelUrl}/api/reply` : "/api/reply";

    // prefer internal call (if Vercel sets VERCEL_URL)
    const replyRes = await fetch(replyEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });
    const replyJson = await replyRes.json();
    const aiReply = replyJson.reply || "Thanks for sharing.";

    const filePath = path.join(process.cwd(), "data", "posts.json");
    let posts = [];
    try { posts = JSON.parse(fs.readFileSync(filePath, "utf8") || "[]"); } catch(e){ posts = []; }
    const newPost = { id: posts.length + 1, text, mood, category, aiReply, time: new Date().toISOString() };
    posts.push(newPost);
    fs.writeFileSync(filePath, JSON.stringify(posts, null, 2));

    res.setHeader("Access-Control-Allow-Origin", "*");
    return res.status(200).json({ success: true, aiReply, post: newPost });
  } catch (err) {
    console.error(err);
    res.setHeader("Access-Control-Allow-Origin", "*");
    return res.status(500).json({ error: "Server error" });
  }
}
