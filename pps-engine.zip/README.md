# PPS ENGINE (Ready-to-deploy)

## What
A minimal Human Thought feed with AI auto-reply (MVP). Frontend static files + Vercel serverless API.

## Quick start
1. Replace VERCEL URL in submit.html (VERCEL_BASE) after you deploy backend.
2. Add OPENROUTER_API_KEY (or other provider) in Vercel Environment Variables.
3. Deploy frontend (GitHub Pages or Vercel static) and backend (Vercel).

## Notes
- posts.json is used for simple persistence (ephemeral on serverless). Move to Firebase/Supabase for permanent storage.
- Do not commit API keys into repo.
